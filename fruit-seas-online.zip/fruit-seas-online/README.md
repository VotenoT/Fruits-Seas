# Fruit Seas Online

Protótipo HTML/Canvas online inspirado em jogos de ilhas, frutas, missões e progressão. Ele usa Cloudflare Workers + Durable Objects + WebSockets para criar salas com código de 6 letras e até 4 jogadores.

> Importante: este projeto não usa imagens, assets, marcas ou arquivos oficiais de jogos existentes. Tudo é desenhado em Canvas para ser um jogo original.

## O que já vem pronto

- Menu inicial para criar sala ou entrar com código de 6 letras.
- Lobby com até 4 jogadores.
- Dono da sala pode começar mesmo sozinho.
- Joystick mobile do lado esquerdo.
- Botões M1, Z, X, C e V do lado direito, otimizados para celular em landscape.
- Botão de modo imersivo com tentativa de fullscreen + trava em landscape.
- 5 ilhas:
  - Ilha Aurora
  - Cogumelo Carmesim
  - Porto Miragem
  - Forja Magmática
  - Templo Celeste
- NPC de missão em cada ilha.
- Área de inimigos em cada ilha.
- 5 inimigos por ilha, renascendo a cada 10 segundos.
- Missão: derrotar 5 inimigos da ilha para ganhar XP e dinheiro.
- Level aumenta a vida máxima: 1000 de vida inicial + 200 por nível.
- 10 frutas equipáveis:
  - Gás
  - Dragon
  - Control
  - Venom
  - Kitsune
  - Luz
  - Gelo
  - Bomba
  - Sombra
  - Fênix
- Servidor autoritativo para dano, inimigos, missões, cooldowns, transformações e estado da sala.

## Estrutura

```text
fruit-seas-online/
├─ public/
│  └─ index.html        # Cliente HTML/Canvas mobile
├─ src/
│  └─ worker.js         # Worker + Durable Object da sala
├─ package.json
├─ wrangler.jsonc
└─ README.md
```

## Como testar localmente

1. Instale Node.js.
2. Abra o terminal dentro da pasta do projeto.
3. Instale as dependências:

```bash
npm install
```

4. Faça login no Cloudflare, se ainda não tiver feito:

```bash
npx wrangler login
```

5. Rode localmente:

```bash
npm run dev
```

6. Abra a URL local exibida pelo Wrangler.

## Como publicar no Cloudflare Workers

```bash
npm run deploy
```

Depois do deploy, acesse a URL `.workers.dev` gerada pelo Cloudflare.

## Como usar com GitHub

1. Crie um repositório no GitHub.
2. Envie todos os arquivos deste projeto.
3. No seu PC, rode `npm install` e `npm run deploy` quando quiser publicar.
4. Para automação futura, dá para configurar GitHub Actions, mas para Durable Objects o caminho mais seguro no começo é usar Wrangler localmente.

## Observações de arquitetura

- O HTML sozinho não cria multiplayer real. Ele é apenas o cliente.
- O Worker recebe as conexões WebSocket.
- Cada sala é um Durable Object separado, usando o código da sala como nome do objeto.
- O cliente só envia intenção: joystick, mira e habilidades.
- O servidor calcula posição, dano, respawn, cooldown e missões.
- Isso reduz bugs e evita que um jogador simplesmente edite o HTML para causar dano infinito.

## Limitações desta versão 0.1

- Não há banco de dados persistente de conta, level permanente ou inventário salvo.
- As frutas já têm identidade visual e mecânica base, mas algumas habilidades complexas foram simplificadas para manter o protótipo estável.
- O projeto usa desenho por Canvas, sem sprites.
- Para milhares de salas ativas, o ideal é migrar os WebSockets do Durable Object para a API hibernável do Cloudflare.

## Próximas melhorias recomendadas

- Salvar progresso em Cloudflare D1 ou KV.
- Adicionar login simples por nome + senha ou token.
- Criar boss por ilha.
- Criar loja de barcos.
- Separar PvE e PvP por zona segura.
- Adicionar minimapa.
- Criar sprites próprios e animações por fruta.
- Balancear dano e cooldowns depois dos testes reais no celular.
